-- ============================================================
-- Forum media storage setup. Run in Supabase SQL Editor, AFTER
-- supabase-schema.sql has already been run.
-- ============================================================

-- Create the storage bucket for forum images (cover images + inline post
-- images). Public read (anyone can view images in published posts),
-- authenticated write (only logged-in users can upload).
insert into storage.buckets (id, name, public, file_size_limit)
values ('forum-media', 'forum-media', true, 3145728) -- 3MB per individual file
on conflict (id) do nothing;

-- Anyone can view forum images (they're embedded in public posts).
create policy "Forum media is publicly viewable"
  on storage.objects for select
  using (bucket_id = 'forum-media');

-- Only logged-in users can upload, and only into their own folder
-- (path convention: forum-media/<user_id>/<filename>), which also makes it
-- trivial to clean up a user's uploads if needed later.
create policy "Logged-in users can upload their own forum media"
  on storage.objects for insert
  with check (
    bucket_id = 'forum-media'
    and auth.uid()::text = (storage.foldername(name))[1]
  );

create policy "Users can delete their own forum media"
  on storage.objects for delete
  using (
    bucket_id = 'forum-media'
    and auth.uid()::text = (storage.foldername(name))[1]
  );


-- ============================================================
-- New columns on forum_threads: cover image + the "preview card" fields
-- (see chat: these help writers, but don't guarantee real Google/social
-- previews on a static site — that needs true per-page server meta tags).
-- ============================================================
alter table public.forum_threads
  add column if not exists cover_image_url text,
  add column if not exists preview_title text,
  add column if not exists preview_description text;
